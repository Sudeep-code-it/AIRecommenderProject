﻿using System;
using System.Configuration;

namespace AIRecommender_CoreEngine
{
    public class RecommenderFactory
    {
        public static RecommenderFactory instance=new RecommenderFactory();

        protected RecommenderFactory() { }

        public IRecommender GetRecommender()
        {

            string classname = ConfigurationManager.AppSettings["Recommender"];
            Type type=Type.GetType(classname);

            return (IRecommender)Activator.CreateInstance(type);    

        }

    }

   
}















// return Correlation.Pearson(baseData.ConvertAll(x => (double)x), otherData.ConvertAll(x => (double)x));


//pearson algo
/*  double sumX = baseData.Sum();
  double sumY = otherData.Sum();

  double sumXY = 0, sumX2 = 0, sumY2 = 0;

  for (int i = 0; i < baseData.Count; i++)
  {
      sumXY += baseData[i] * otherData[i];
      sumX2 += baseData[i] * baseData[i];
      sumY2 += otherData[i] * otherData[i];
  }

  double numerator = (baseData.Count * sumXY) - (sumX * sumY);
  double denominator = Math.Sqrt((baseData.Count * sumX2 - (sumX * sumX)) * (baseData.Count * sumY2 - (sumY * sumY)));

  if (denominator == 0)
      return 0;

  return numerator / denominator;*/




///////////////////////////////

/* if (baseData.Count == otherData.Count)
 {
     for (int i = 0; i < otherData.Count; i++)
     {
         if (baseData[i] == 0 || otherData[i] == 0)
         {
             baseData[i] += 1;
             otherData[i] += 1;
         }
     }
 }
 else if (baseData.Count > otherData.Count)
 {
     for (int i = otherData.Count; i < baseData.Count; i++)
     {
         otherData.Add(1);
         baseData[i] = baseData[i] + 1;
     }
 }
 else
 {
     otherData = otherData.Take(baseData.Count).ToList();
 }
*/
/*  Console.WriteLine();
  Console.WriteLine("After updating");
  Console.Write("baseArray:  ");
  foreach (int i in baseData)
      Console.Write(i + " ");
  Console.WriteLine();
  Console.Write("otherArray:  ");
  foreach (int i in otherData)
      Console.Write(i + " ");*/

//return Correlation.Pearson(baseData.ConvertAll(x=>(double)x), otherData.ConvertAll(x => (double)x));


