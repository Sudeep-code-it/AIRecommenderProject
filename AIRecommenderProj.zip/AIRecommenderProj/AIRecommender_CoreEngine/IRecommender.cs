﻿using System.Collections.Generic;

namespace AIRecommender_CoreEngine
{
    public interface IRecommender
    {
        double GetCorellation(List<int> baseDate, List<int> otherDate);

    }

   
}
