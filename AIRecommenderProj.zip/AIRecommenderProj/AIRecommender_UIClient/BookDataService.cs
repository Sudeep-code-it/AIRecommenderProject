﻿using System;
using AIRecommender_Cacher;
using AIRecommender_DataLoader;
using AIRecommender_Entities;

namespace AIRecommender_UIClient
{
  public class BookDataService
  {
      public static BookDetails GetBookDetails()
      {
        IDataCacher dataCacher= CacherFactory.instance.GetCacher();
        
        IDataLoader dataLoader= DataLoaderFactory.instance.GetDataLoader();

            Console.WriteLine();
            Console.WriteLine($"Iam using {dataCacher}");

            if (dataCacher.GetBookDetails() == null)
            {
                Console.WriteLine("Without Using Cache");
                BookDetails bookDetails =dataLoader.Load();
                dataCacher.SetBookDetails(bookDetails);
            }
            else 
                Console.WriteLine("By Using Cache");

            Console.WriteLine();

            return dataCacher.GetBookDetails();

       }
    }
  
}
