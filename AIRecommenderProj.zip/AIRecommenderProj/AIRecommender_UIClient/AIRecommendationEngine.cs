﻿using AIRecommender_CoreEngine;
using AIRecommender_DataAggrigator;
using AIRecommender_DataLoader;
using AIRecommender_Entities;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIRecommender_UIClient
{
    public class AIRecommendationEngine
    { 
         
         private IRecommender recommender=null;


        public AIRecommendationEngine()
        {
            this.recommender = RecommenderFactory.instance.GetRecommender();
        }

        public List<Book> Recommend(Preference preference,int limit) 
        {


            BookDetails bookDetails = BookDataService.GetBookDetails();



            IRatingAggrigator ratingsAggrigator= new RatingsAggrigator();
            ConcurrentDictionary<string, List<int>> aggrigatedRatingDict= ratingsAggrigator.Aggrigate(bookDetails, preference);

            

            int[] baseData = bookDetails.bookUserRatings.Where(r=>r.ISBN==preference.ISBN).Select(r=>r.Rating).ToArray();

           
            List<string>recommendedBooksISBN= aggrigatedRatingDict.OrderByDescending(record => recommender.GetCorellation(baseData.ToList(), record.Value)).Select(record => record.Key).Take(limit).ToList();


            List<Book> finalBookList =bookDetails.books.Where(book=> recommendedBooksISBN.Contains(book.ISBN)).ToList();

            return finalBookList;
        }
    }
}

















/*Dictionary<string, double> answer = new Dictionary<string, double>();
foreach (var item in aggrigatedRatingDict.Keys)
{
    answer.Add(item, recommender.GetCorellation(baseData.ToList(), aggrigatedRatingDict[item]));

}


List<string> recommendedBooksISBN = answer.OrderByDescending(x => x.Value).Select(x => x.Key).Take(limit).ToList();

Dictionary<string, double> printing = answer.OrderByDescending(y => y.Value).Take(limit).ToDictionary(y => y.Key, y => y.Value);

foreach (var item in printing)
{
    Console.WriteLine(item.Key + " " + item.Value);
}
*/