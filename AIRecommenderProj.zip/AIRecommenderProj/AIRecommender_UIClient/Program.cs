﻿using AIRecommender_DataAggrigator;
using AIRecommender_DataLoader;
using AIRecommender_Entities;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading.Tasks;

namespace AIRecommender_UIClient
{
    internal partial class Program
    {
        static void Main(string[] args)
        {
            Stopwatch stopwatch = Stopwatch.StartNew();

            AIRecommendationEngine aIRecommendationEngine = new AIRecommendationEngine();
            List<Book> recommendedBooks = new List<Book>();

            string userAns = "";

            do 
            {
                Preference p = new Preference();

                Console.Write("Enter the ISBN: ");
                p.ISBN= Console.ReadLine();

                Console.Write("Enter the State: ");
                p.State = Console.ReadLine();

                Console.Write("Enter the Age: ");
                p.Age=int.Parse(Console.ReadLine());

                Console.Write("Enter the Limit(number of recommendations you need): ");
                int limit = int.Parse(Console.ReadLine());

                stopwatch.Restart();

                recommendedBooks = aIRecommendationEngine.Recommend(p, limit);

                Console.WriteLine("Your recommendations are: ");

                foreach (Book b in recommendedBooks)
                {
                    Console.WriteLine("ISBN: " + b.ISBN + "      Book_Title: " + b.BookTitle);
                }
                Console.WriteLine();
                Console.WriteLine("Time Taken: " + stopwatch.ElapsedMilliseconds);
                Console.WriteLine();

                Console.WriteLine("Do you want to continue? (y/n)");
                userAns= Console.ReadLine();


            } while (userAns=="y");


        }


    }

}






/*p.ISBN = "0425182908";
p.Age = 40;
p.State = "california";*/







/* static void Main11(string[] args)
 {
     BookDetails bookDetails = new BookDetails();
     bookDetails.books = new List<Book>();
     bookDetails.bookUserRatings = new List<BookUserRating>();
     bookDetails.users = new List<User>();

     *//*  Task task1 = Task.Run(() =>
       {
           using (StreamReader sr1 = new StreamReader("BX-Books.csv"))
           {
               int skip1 = 0;
               while (!sr1.EndOfStream)
               {
                   string line1 = sr1.ReadLine();

                   if (skip1 == 0)
                   {
                       skip1 = 1;
                       continue;
                   }

                   string delimiter = "\";\"";

                   string[] parts1 = line1.Split(new[] { delimiter }, StringSplitOptions.None);


                   Book book = new Book();
                   book.ISBN = parts1[0].Trim('"');
                   book.BookTitle = parts1[1];
                   book.BookAuthor = parts1[2];
                   book.YearOfPublication = parts1[3];
                   book.Publisher = parts1[4];
                   book.ImageUrlSmall = parts1[5];
                   book.ImageUrlMedium = parts1[6];
                   book.ImageUrlLarge = parts1[7].Trim('"');

                   bookDetails.books.Add(book);

               }

               // Console.WriteLine("Competed books");
           }
       });


       task1.Wait();

       foreach(Book book in bookDetails.books)
       {
           Console.WriteLine(book.ISBN+" "+book.BookTitle+" "+book.BookAuthor+" "+book.YearOfPublication+" "+book.Publisher+" "+book.ImageUrlSmall+" "+book.ImageUrlMedium+" "+book.ImageUrlLarge);
       }*//*



     Task task3 = Task.Run(() =>
     {
         int skip3 = 0;
         using (StreamReader sr3 = new StreamReader("BX-Users.csv"))
         {
             while (!sr3.EndOfStream)
             {
                 string line3 = sr3.ReadLine();
                 if (skip3 == 0)
                 {
                     skip3 = 1;
                     continue;

                 }

                // string delimiter = "\";";

                 string[] parts3 = line3.Split(';').Select(s=> s.Trim('"')).ToArray();


                 User user = new User();

                 user.UserId = parts3[0];
                 string loc = parts3[1];

                 List<string> locparts = loc.Split(',').Select(s => s.Trim(' ')).ToList();

                 user.City = locparts.Count >= 1 ? locparts[0] : "";
                 user.State = locparts.Count >= 2 ? locparts[1] : "";
                 user.Country = locparts.Count >= 3 ? locparts[2] : "";

                 int a;
                 if (parts3[2] != "NULL")
                 { int.TryParse(parts3[2], out a); 
                 user.Age = a;
                 }
                 else
                     user.Age = -1;

                 bookDetails.users.Add(user);

                 //  Console.WriteLine("Competed users");

             }
         }
     });

     task3.Wait();

     foreach(var user in bookDetails.users)
     {
         Console.WriteLine(user.UserId+" "+user.City+" "+user.State+" "+user.Country+" "+user.Age);
     }



 }*/


