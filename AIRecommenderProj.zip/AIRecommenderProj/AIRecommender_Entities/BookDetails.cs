﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIRecommender_Entities
{
    public class BookDetails
    {
        public List<BookUserRating> bookUserRatings;
        public List<Book> books;
        public List<User> users;
    }
}
