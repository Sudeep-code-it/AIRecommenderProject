﻿using System.Collections.Generic;

namespace AIRecommender_Entities
{
    public class BookUserRating
    {
        public List<User>users { get; set; }
        public int Rating { get; set; } 
        public string UserID { get; set; }

        public string ISBN { get; set; }
    }
}