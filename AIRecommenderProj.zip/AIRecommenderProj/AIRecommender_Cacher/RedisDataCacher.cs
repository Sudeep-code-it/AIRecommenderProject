﻿using AIRecommender_Entities;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using StackExchange.Redis;

namespace AIRecommender_Cacher
{

    public class RedisDataCacher : IDataCacher
    {

        private readonly ConnectionMultiplexer _redis;
        private readonly IDatabase _db;
        public RedisDataCacher()
        {

            _redis = ConnectionMultiplexer.Connect("localhost:6379");
            _db = _redis.GetDatabase();
        }

        public BookDetails GetBookDetails()
        {
            string json = _db.StringGet("bookDetails");
            if (json == null)
                return null;
            return JsonConvert.DeserializeObject<BookDetails>(json);
        }

        public void SetBookDetails(BookDetails bookDetails)
        {
            string json = JsonConvert.SerializeObject(bookDetails);
            _db.StringSet("bookDetails", json);
        }

       
    }
}
