﻿using AIRecommender_Entities;

namespace AIRecommender_Cacher
{
    public interface IDataCacher
    {
        BookDetails GetBookDetails();

        void SetBookDetails(BookDetails bookDetails);

        //BookDetails bookDetails { get; set; }
    }
}
