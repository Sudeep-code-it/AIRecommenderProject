﻿using AIRecommender_Cacher;
using System;
using System.Configuration;
using System.Reflection;



namespace AIRecommender_Cacher
{
    public class CacherFactory
    {
        public static readonly CacherFactory instance =new CacherFactory();

        protected CacherFactory()
        { }

        public IDataCacher GetCacher()
        {
            string className = ConfigurationManager.AppSettings["Cacher"];
            Type type = Type.GetType(className);
            return (IDataCacher)Activator.CreateInstance(type);

        }

}
}



















/*public IDataCacher GetCacher()
{
    string methodPath = ConfigurationManager.AppSettings["Cacher"];

    string[] parts = methodPath.Split('.');
    if (parts.Length < 2)
        throw new ArgumentException("Invalid method path specified in configuration");

    string methodName = parts[parts.Length - 1];

    string className = string.Join(".", parts, 0, parts.Length - 1);

    Type type = Type.GetType(className);
    if (type == null)
        throw new ArgumentException($"Type '{className}' specified in configuration not found");

    // Get the static method
    var method = type.GetMethod(methodName, BindingFlags.Public | BindingFlags.Static);
    if (method == null)
        throw new ArgumentException($"Static method '{methodName}' not found in type '{className}'");

    // Invoke the static method to get the instance
    var instance = method.Invoke(null, null);

    return (IDataCacher)instance;
}*/