﻿using AIRecommender_Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.Caching;
using System.Text;
using System.Threading.Tasks;


namespace AIRecommender_Cacher
{
    public class MemDataCacher : IDataCacher
    {

        MemoryCache cache = MemoryCache.Default;

        public BookDetails GetBookDetails()
        {
            BookDetails cachedBook = (BookDetails)cache["bookKey"];
            return cachedBook;
        }

        public void SetBookDetails(BookDetails bookDetails)
        {
            var bookdetails = bookDetails;
            cache["bookKey"]=bookdetails;
        }
    }

}
