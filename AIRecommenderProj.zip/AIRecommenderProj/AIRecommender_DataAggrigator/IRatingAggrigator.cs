﻿using AIRecommender_Entities;
using System.Collections.Concurrent;
using System.Collections.Generic;

namespace AIRecommender_DataAggrigator
{
    public interface IRatingAggrigator
    {
        ConcurrentDictionary<string, List<int>> Aggrigate(BookDetails b, Preference p);
    }
}
