﻿using AIRecommender_Entities;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIRecommender_DataAggrigator
{
    public class RatingsAggrigator : IRatingAggrigator
    {
      
        public ConcurrentDictionary<string, List<int>>Aggrigate(BookDetails bookDetails, Preference preference)
        {
           AgeGroupType1 ageGroup=new AgeGroupType1();

          HashSet<string>eligibleUsers = new HashSet<string>();
            
                foreach(User user in bookDetails.users)
                {
                    if (user.State !="" && user.State == preference.State && ageGroup.Check(preference.Age, user.Age))
                    {
                        eligibleUsers.Add(user.UserId);
                    }
                }


            ConcurrentDictionary<string, List<int>>allBooksRatingDict = new ConcurrentDictionary<string, List<int>>();

             foreach(BookUserRating bookUserRating in bookDetails.bookUserRatings)
             {
               if (eligibleUsers.Contains(bookUserRating.UserID))
               { 
                   allBooksRatingDict.AddOrUpdate(bookUserRating.ISBN, new List<int>{bookUserRating.Rating}, (key, value) => {
                       value.Add(bookUserRating.Rating);
                       return value;
                   });
                      
               }
               
             }


            return allBooksRatingDict;
        }
    }
}
















/*//Parallel.ForEach(bookDetails.bookUserRatings, bookUserRating=>
foreach (BookUserRating bookUserRating in bookDetails.bookUserRatings)
{
    //bookUserRating.ISBN==preference.ISBN ||
    if (eligibleUsers.Contains(bookUserRating.UserID))
    {
        *//* 
         if (allBooksRatingDict.ContainsKey(bookUserRating.ISBN))
         { allBooksRatingDict[bookUserRating.ISBN].Add(bookUserRating.Rating); }
         else
             allBooksRatingDict.GetOrAdd(bookUserRating.ISBN, new List<int>() { bookUserRating.Rating });
*//*
        allBooksRatingDict.AddOrUpdate(bookUserRating.ISBN, new List<int> { bookUserRating.Rating }, (key, oldvalue) => {
            oldvalue.Add(bookUserRating.Rating);
            return oldvalue;
        });

    }

}//);

*//* foreach (KeyValuePair<string, List<int>> kv in allBooksRatingDict)
 {
     Console.Write("\n" + kv.Key+" ");
     foreach (int i in kv.Value)
         Console.Write(i + " ");

 }*/
