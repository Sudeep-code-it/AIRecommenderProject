﻿namespace AIRecommender_DataAggrigator
{
    public class Preference
    {
        public string ISBN { get; set; }
        public string State { get; set; }
        public int Age { get; set; }
    }
}
