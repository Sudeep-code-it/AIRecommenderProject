﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;

namespace AIRecommender_DataAggrigator
{
  
    public class AgeGroupType1
    {
        private List<AgeGroup> ageGroups;

        public AgeGroupType1()
        {
            LoadAgeGroupsFromConfig();
        }

        private void LoadAgeGroupsFromConfig()
        {
            try
            {
                string json = File.ReadAllText("age_groups.json");
                dynamic config = JsonConvert.DeserializeObject(json);

                ageGroups = new List<AgeGroup>();
                foreach (var group in config.ageGroups)
                {
                    ageGroups.Add(new AgeGroup { MinAge = group.min, MaxAge = group.max });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error loading age groups from config file: " + ex.Message);
            }
        }

        public bool Check(int age1, int age2)
        {
            foreach (var group in ageGroups)
            {
                if (age1 >= group.MinAge && age1 <= group.MaxAge && age2 >= group.MinAge && age2 <= group.MaxAge)
                {
                    return true;
                }
            }
            return false;
        }
    }

    public class AgeGroup
    {
        public int MinAge { get; set; }
        public int MaxAge { get; set; }
    }

}
