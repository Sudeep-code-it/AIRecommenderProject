﻿using AIRecommender_CoreEngine;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

namespace AIRecommender_CoreEngine_UnitTest
{
    [TestClass]
    public class PearsonRecommender_UnitTest
    {
         private IRecommender recommender = null;

        [TestInitialize]
        public void Init()
        {
            recommender = new PearsonRecommender();

        }

        [TestCleanup]
        public void Cleanup()
        {
            recommender = null;
        }


        [TestMethod]
        public void PearsonRecommender_WhenGivenEmptyLists_GivesOutputAsZero()
        {
             List<int> baseData = new List<int>() { };
             List<int> otherData = new List<int>() { };

            Assert.AreEqual(0, recommender.GetCorellation(baseData, otherData));
             

        }

        [TestMethod]
        public void PearsonRecommender_WhenGivenListOfSameSizeAndSameData_GivesOutputAsOne()
        {
            List<int> baseData = new List<int>() { 1,2,3,4,5};
            List<int> otherData = new List<int>() { 6,7,8};

            Assert.AreEqual(-0.832059807561161, recommender.GetCorellation(baseData, otherData),0.0001);


        }

        [TestMethod]
        public void PearsonRecommender_WhenGivenListOfSameSizeAndSizeData_GivesOutputAsOne()
        {
            List<int> baseData = new List<int>() { 1, 2, 3, 4, 5 };
            List<int> otherData = new List<int>() { 1, 2, 3, 4, 5 };

            Assert.AreEqual(1, recommender.GetCorellation(baseData, otherData), 0.0001);


        }

        [TestMethod]
        public void PearsonRecommender_WhenGivenListOfSameSizeAndValidData_GivesCorrectOutput()
        {
            List<int> baseData = new List<int>() { 1, 2, 3, 4, 5 };
            List<int> otherData = new List<int>() { 1,2,3,6,5};

            Assert.AreEqual(0.914991421995628, recommender.GetCorellation(baseData, otherData), 0.0001 );
        }

        [TestMethod]
        public void PearsonRecommender_WhenBaselistIsBiggerThanOtherlist_IncreasesTheSizeOfOtherList()
        {
            List<int> baseData = new List<int>() { 1, 2, 3, 4, 5 };
            List<int> otherData = new List<int>() { 1, 2, 3};

            recommender.GetCorellation(baseData, otherData);

            Assert.AreEqual(5,otherData.Count);
        }

        [TestMethod]
        public void PearsonRecommender_WhenBaselistIsSmallerThanOtherlist_DecreasesTheSizeOfOtherList()
        {
            List<int> baseData = new List<int>() { 1, 2, 3, 4, 5 };
            List<int> otherData = new List<int>() { 1, 2, 3 ,4,5,6,7,8};

            recommender.GetCorellation(baseData, otherData);

            Assert.AreEqual(baseData.Count, otherData.Count);
        }

        [TestMethod]
        public void PearsonRecommender_WhenGivenListContainingZero_IncreasesThemAndCorrespondingByOne()
        {
            List<int> baseData = new List<int>() { 1, 2, 0, 4, 5 };
            List<int> otherData = new List<int>() { 1, 0, 3, 4};

            recommender.GetCorellation(baseData, otherData);

            Assert.AreEqual(1, otherData[1]);
            Assert.AreEqual(3, baseData[1]);

            Assert.AreEqual(4, otherData[2]);
            Assert.AreEqual(1, baseData[2]);

            Assert.AreEqual(1, otherData[4]);
            Assert.AreEqual(6, baseData[4]);


        }


    }
}
       
    

