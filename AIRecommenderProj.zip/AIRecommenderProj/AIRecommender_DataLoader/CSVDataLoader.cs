﻿using AIRecommender_Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIRecommender_DataLoader
{
    public partial class CSVDataLoader : IDataLoader
    {
        public BookDetails Load()
        {
            BookDetails bookDetails = new BookDetails();
            bookDetails.books = new List<Book>();
            bookDetails.bookUserRatings = new List<BookUserRating>();
            bookDetails.users = new List<User>();

            Task task1,task2,task3;

            try
            {
                task1 = Task.Run(() =>
                {
                    using (StreamReader sr1 = new StreamReader("BX-Books.csv"))
                    {
                        int skip1 = 0;
                        while (!sr1.EndOfStream)
                        {
                            string line1 = sr1.ReadLine();

                            if (skip1 == 0)
                            {
                                skip1 = 1;
                                continue;
                            }

                            string delimiter = "\";\"";

                            string[] parts1 = line1.Split(new[] { delimiter }, StringSplitOptions.None);


                            Book book = new Book();
                            book.ISBN = parts1[0].Trim('"');
                            book.BookTitle = parts1[1];
                            book.BookAuthor = parts1[2];
                            book.YearOfPublication = parts1[3];
                            book.Publisher = parts1[4];
                            book.ImageUrlSmall = parts1[5];
                            book.ImageUrlMedium = parts1[6];
                            book.ImageUrlLarge = parts1[7].Trim('"');

                            bookDetails.books.Add(book);

                        }

                    }
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw new Exception();
            }

            try
            {
                task2 = Task.Run(() =>
                {
                    int skip2 = 0;
                    using (StreamReader sr2 = new StreamReader("BX-Book-Ratings.csv"))
                    {
                        while (!sr2.EndOfStream)
                        {
                            string line2 = sr2.ReadLine();
                            if (skip2 == 0)
                            {
                                skip2 = 1;
                                continue;
                            }
                            List<string> parts2 = line2.Split(';').Select(s => s.Trim('"')).ToList();


                            BookUserRating bookUserRating = new BookUserRating();
                            bookUserRating.UserID = parts2[0];
                            bookUserRating.ISBN = parts2[1];
                            bookUserRating.Rating = int.Parse(parts2[2]);

                            bookDetails.bookUserRatings.Add(bookUserRating);


                        }
                    }
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw new Exception();
            }

            try
            {
                task3 = Task.Run(() =>
                {
                    int skip3 = 0;
                    using (StreamReader sr3 = new StreamReader("BX-Users.csv"))
                    {
                        while (!sr3.EndOfStream)
                        {
                            string line3 = sr3.ReadLine();
                            if (skip3 == 0)
                            {
                                skip3 = 1;
                                continue;

                            }


                            string[] parts3 = line3.Split(';').Select(s => s.Trim('"')).ToArray();


                            User user = new User();

                            user.UserId = parts3[0];
                            string loc = parts3[1];

                            List<string> locparts = loc.Split(',').Select(s => s.Trim(' ')).ToList();

                            user.City = locparts.Count >= 1 ? locparts[0] : "";
                            user.State = locparts.Count >= 2 ? locparts[1] : "";
                            user.Country = locparts.Count >= 3 ? locparts[2] : "";

                            int a;
                            if (parts3[2] != "NULL")
                            {
                                int.TryParse(parts3[2], out a);
                                user.Age = a;
                            }
                            else
                                user.Age = -1;

                            bookDetails.users.Add(user);


                        }
                    }
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw new Exception();
            }

            Task.WaitAll(task1, task2, task3);


            Console.WriteLine("Completed data loading using CSVDataLoader.");
            Console.WriteLine();

            return bookDetails;
         


        }

    }




}
