﻿using AIRecommender_Entities;
using System;

namespace AIRecommender_DataLoader
{
    public class DbDataLoader : IDataLoader
        {
            public BookDetails Load()
            {
                throw new NotImplementedException();
            }
        }

}
