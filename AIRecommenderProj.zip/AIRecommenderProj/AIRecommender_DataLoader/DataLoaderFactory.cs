﻿using AIRecommender_DataLoader;
using System;
using System.Configuration;

namespace AIRecommender_DataLoader
{

        public class DataLoaderFactory
        {
            protected DataLoaderFactory() {}

            public static readonly DataLoaderFactory instance =new DataLoaderFactory();

            public IDataLoader GetDataLoader()
            {
                string className = ConfigurationManager.AppSettings["Loader"];

                Type type = Type.GetType(className);
                return (IDataLoader)Activator.CreateInstance(type);
            }
        }



}
