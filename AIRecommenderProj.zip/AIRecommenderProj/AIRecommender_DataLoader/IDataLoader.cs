﻿using AIRecommender_Entities;

namespace AIRecommender_DataLoader
{
    public interface IDataLoader
    {
      BookDetails Load();
    }




}
